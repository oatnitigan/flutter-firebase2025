package com.example.firebase2025

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
